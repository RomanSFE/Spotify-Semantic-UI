(function ($) {
    "use strict";
	
	$(document).ready(function() {
       
      $('.ui.dropdown')
		  .dropdown();

	  $('.activating.element')
		  .popup();

	// music player st
	
	// music player ed
	   
	});
	
	
	
})(jQuery);